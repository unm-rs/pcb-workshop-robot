*PADS-LIBRARY-PART-TYPES-V9*

M20-9990645 HDRV6W66P0X254_1X6_1524X254X864P I CON 7 1 0 0 0
TIMESTAMP 2026.04.02.11.20.41
"Mouser Part Number" 855-M20-9990645
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-9990645?qs=Jph8NoUxIfWe7BJQOhiVRg%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-9990645
"Description" M20: 6 Pos Plug SIL Straight 3mm THT Connector 6.1mm pin Gold
"Datasheet Link" https://content.harwin.com/m/0df15f6e0f9f48e2/original/DRG-00479-Technical-Drawing-Datasheet-M20-999-pdf.pdf
"Geometry.Height" 8.64mm
GATE 1 6 0
M20-9990645
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6

*END*
*REMARK* SamacSys ECAD Model
322772/1823112/2.50/6/2/Connector
