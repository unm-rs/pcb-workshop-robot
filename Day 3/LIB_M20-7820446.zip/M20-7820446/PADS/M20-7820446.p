*PADS-LIBRARY-PART-TYPES-V9*

M20-7820446 RHDR4W70P0X254_1X4_1056X250X850P I CON 7 1 0 0 0
TIMESTAMP 2026.04.02.11.18.07
"Mouser Part Number" 855-M20-7820446
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-7820446?qs=vF78I%252BjhbY8%252Bno0H8mp9XA%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-7820446
"Description" M20: 4 Pos Receptacle SIL Straight 3mm THT Connector 8.5mm high Tin
"Datasheet Link" https://content.harwin.com/m/c2ac50ebb1c800d5/original/DRG-00385-Technical-Drawing-Datasheet-M20-782-pdf.pdf
"Geometry.Height" 8.5mm
GATE 1 4 0
M20-7820446
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4

*END*
*REMARK* SamacSys ECAD Model
632137/1823112/2.50/4/2/Connector
